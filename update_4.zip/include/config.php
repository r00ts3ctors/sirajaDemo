<?php
$host     = "localhost";    // Nama host
$username = "root";         // Username database
$password = "";   // Password database
$database = "db_rawat_jalan";   // Nama database
